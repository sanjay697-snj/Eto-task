document.addEventListener('DOMContentLoaded', function () {

  
    document.querySelectorAll('nav a').forEach(anchor => {
        anchor.addEventListener('click', function(e){
          e.preventDefault();
           const targetId = this.getAttribute('href');
           const targetElement = document.querySelector(targetId);

          if(targetElement){
            window.scrollTo({
                top: targetElement.offsetTop,
                behavior: 'smooth'
            });
          }

       });
      });

   
    const carousels = document.querySelectorAll('.carousel-container');
    carousels.forEach(carousel=>{
        const track = carousel.querySelector('.carousel');
        const prevButton = carousel.querySelector('.prev-btn');
        const nextButton = carousel.querySelector('.next-btn');
        const slides = track.querySelectorAll('.carousel-item');
        let currentIndex = 0;

    function updateCarousel() {
          track.style.transform = `translateX(-${currentIndex * 100}%)`;
        }
    nextButton.addEventListener('click', () => {
        currentIndex = (currentIndex + 1) % slides.length;
         updateCarousel();
         });

    prevButton.addEventListener('click', () => {
          currentIndex = (currentIndex - 1 + slides.length) % slides.length;
           updateCarousel();
           });

      updateCarousel();
   });


  
    document.querySelectorAll('.details-button').forEach(item =>{
        item.addEventListener('click', ()=>{
          const modalId = item.getAttribute('data-modal');
          const modal = document.getElementById(modalId);
          modal.style.display = 'block';
         });
     });

    document.querySelectorAll('.modal .close-button').forEach(button=>{
       button.addEventListener('click',(event)=>{
        const modal = event.target.closest('.modal');
          modal.style.display = 'none';
       });
    });
    window.addEventListener('click', (event) => {
      if (event.target.classList.contains('modal')) {
         event.target.style.display = 'none';
         }
     });


});